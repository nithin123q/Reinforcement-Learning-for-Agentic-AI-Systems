
# RL Agentic Final – Latest Version

This project is a **reinforcement learning-enhanced agentic research system**
designed to align with the *Take-Home Final: Reinforcement Learning for Agentic AI Systems* requirements.

It demonstrates:

- **Value-Based Learning** via tabular **Q-Learning** for workflow decisions
- **Exploration Strategy** via **UCB1 Bandit** for source (tool) selection
- Integration with a **Research/Analysis Agentic System**:
  - SearchAgent (information gathering)
  - SummarizerAgent (synthesis)
  - RLController (agent orchestration)

## Project Structure

```
rl_agentic_final_latest/
├── data/
│   └── tasks.json          # Simulated research tasks
├── logs/
│   └── rl_metrics.csv      # Created after training
├── src/
│   ├── agents.py           # Agents + RLController
│   ├── bandit.py           # UCBBandit (exploration strategy)
│   ├── environment.py      # Reward + quality level helpers
│   ├── qlearning.py        # QLearningAgent (value-based RL)
│   ├── main_fixed.py       # Baseline (no RL)
│   ├── main.py             # RL training script
│   └── plot_learning_curve.py  # Utility script to generate plots
└── README.md
```

## How to Run

1. (Optional) Create and activate a virtual environment and install matplotlib:

   ```bash
   python -m venv env
   source env/bin/activate        # macOS/Linux
   # env\Scripts\activate       # Windows

   pip install matplotlib
   ```

2. Run the **baseline** (non-RL) pipeline:

   ```bash
   cd rl_agentic_final_latest
   python -m src.main_fixed
   ```

   This simulates a simple controller that always:
   - queries `wikipedia` once
   - summarizes
   - does not learn from experience.

3. Run the **RL training** pipeline:

   ```bash
   cd rl_agentic_final_latest
   python -m src.main
   ```

   You should see output like:

   ```
   Episode 1: avg reward = ...
   Episode 2: avg reward = ...
   ...
   ```

   After training, check:

   - `logs/rl_metrics.csv` for the learning curve data
     (columns: `episode, avg_reward, avg_searches`).

4. Plot the learning curves:

   ```bash
   python -m src.plot_learning_curve
   ```

   This generates:

   - `logs/learning_curve_reward.png`   (reward vs episode)
   - `logs/learning_curve_searches.png` (avg searches vs episode)

## How This Maps to the Final Requirements

- **RL Approaches (Choose TWO)**:
  - Value-Based Learning: Q-Learning (`QLearningAgent` in `qlearning.py`)
  - Exploration Strategies: UCB1 Bandit (`UCBBandit` in `bandit.py`)

- **Agentic System Type**:
  - Research/Analysis Agents:
    - `SearchAgent` (search/information gathering)
    - `SummarizerAgent` (synthesis)
    - `RLController` (learned workflow + tool selection)

- **Experimental Design & Results**:
  - Baseline vs RL:
    - Baseline: `main_fixed.py` (fixed source, no learning)
    - RL: `main.py` (bandit + Q-learning, learns over episodes)
  - Metrics:
    - Average reward per episode
    - Average number of searches per task
  - Visualizations:
    - Reward learning curve
    - Search-efficiency curve

Use this as the core implementation and connect it to your written report and
10-minute video by:
  - Explaining the state, action, reward design
  - Relating the components to agentic AI (controller, tools, agents)
  - Presenting the plots from `plot_learning_curve.py` as your learning curves.
