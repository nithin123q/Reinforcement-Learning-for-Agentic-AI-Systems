
"""Agent definitions and RL-based controller for the research system."""

from environment import quality_level

class SearchAgent:
    """Simulated search agent.

    In a real system, this would call web search APIs or tools.
    Here we just return a dummy document indicating the source and query.
    """
    def search(self, query, source: str):
        return {
            "source": source,
            "content": f"Simulated content about '{query}' from {source}"
        }


class SummarizerAgent:
    """Simulated summarization agent.

    In a real system, this could call an LLM or summarization model.
    Here we just concatenate and truncate the content.
    """
    def summarize(self, documents):
        combined = " ".join([doc["content"] for doc in documents])
        return f"Summary: {combined[:200]}..."


class ControllerAgent:
    """Baseline (non-RL) controller with a fixed workflow.

    - Always queries a single fixed source (wikipedia)
    - Always summarizes once and stops
    - Does NOT learn from experience
    """
    def __init__(self, search_agent: SearchAgent, summarizer_agent: SummarizerAgent):
        self.search_agent = search_agent
        self.summarizer_agent = summarizer_agent

    def run_fixed_pipeline(self, task):
        doc = self.search_agent.search(task["query"], source="wikipedia")
        summary = self.summarizer_agent.summarize([doc])
        return summary


class RLController:
    """RL-based controller that uses a bandit + Q-learning for workflow.

    - UCBBandit chooses which SOURCE to query (blog, wikipedia, scholar, news)
    - QLearningAgent chooses which ACTION to take:
        * 'search_more'  -> query another source
        * 'summarize'    -> stop exploration and summarize collected docs
        * 'stop'         -> stop without summarizing (penalized)

    The controller converts the current search state into a small discrete
    state representation for Q-learning:
        state = (doc_bucket, quality_level)

    where:
        doc_bucket    in {0,1,2,3} (3 means 3 or more docs)
        quality_level in {"low","medium","high"} based on average source reward
    """
    def __init__(self, search_agent, summarizer_agent, bandit, q_agent):
        self.search_agent = search_agent
        self.summarizer_agent = summarizer_agent
        self.bandit = bandit
        self.q_agent = q_agent
        self.actions = ["search_more", "summarize", "stop"]

    def _get_state(self, docs, doc_rewards):
        # Bucketize document count
        doc_count = len(docs)
        if doc_count >= 3:
            doc_bucket = 3
        else:
            doc_bucket = doc_count

        # Average source reward so far
        if doc_rewards:
            avg_reward = sum(doc_rewards) / len(doc_rewards)
        else:
            avg_reward = 0.0

        q_level = quality_level(avg_reward)
        # State is (doc_bucket, quality_level_str)
        return (doc_bucket, q_level)

    def run_episode(self, task, reward_fn):
        """Run one RL episode for a single task.

        Args:
            task: a dict with fields like 'query', 'best_source', etc.
            reward_fn: function(task, chosen_source) -> float

        Returns:
            total_reward (float): sum of step rewards for this episode.
            total_searches (int): how many 'search_more' actions were taken.
        """
        docs = []
        doc_rewards = []
        done = False
        state = self._get_state(docs, doc_rewards)
        total_reward = 0.0
        total_searches = 0

        while not done:
            action = self.q_agent.select_action(state)

            if action == "search_more":
                chosen_source = self.bandit.select_action()
                doc = self.search_agent.search(task["query"], chosen_source)
                r_src = reward_fn(task, chosen_source)
                self.bandit.update(chosen_source, r_src)
                docs.append(doc)
                doc_rewards.append(r_src)
                total_searches += 1

                # Small negative reward for computation/tool cost
                step_reward = -0.05

            elif action == "summarize":
                if docs:
                    summary = self.summarizer_agent.summarize(docs)
                    avg_r = sum(doc_rewards) / len(doc_rewards)
                    # Higher quality docs -> larger positive reward
                    step_reward = avg_r * 2.0
                else:
                    summary = self.summarizer_agent.summarize(
                        [{"content": "No documents collected."}]
                    )
                    # Summarizing without any docs is bad
                    step_reward = -0.5
                done = True

            elif action == "stop":
                # Stopping without summarizing is mildly negative
                step_reward = -0.3
                done = True

            else:
                # Unknown action (should not happen)
                step_reward = -0.1
                done = True

            total_reward += step_reward
            next_state = self._get_state(docs, doc_rewards)
            self.q_agent.update(state, action, step_reward, next_state)
            state = next_state

        return total_reward, total_searches
