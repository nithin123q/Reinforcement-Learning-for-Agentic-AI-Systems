
"""Utility script to plot learning curves from rl_metrics.csv.

Run after training:

    python -m src.plot_learning_curve
"""
import csv
import matplotlib.pyplot as plt

def load_metrics(path="logs/rl_metrics.csv"):
    episodes = []
    avg_rewards = []
    avg_searches = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            episodes.append(int(row["episode"]))
            avg_rewards.append(float(row["avg_reward"]))
            avg_searches.append(float(row["avg_searches"]))
    return episodes, avg_rewards, avg_searches

if __name__ == "__main__":
    episodes, avg_rewards, avg_searches = load_metrics()

    # Plot average reward
    plt.figure()
    plt.plot(episodes, avg_rewards, marker="o")
    plt.xlabel("Episode")
    plt.ylabel("Average Reward")
    plt.title("Learning Curve: Average Reward per Episode")
    plt.grid(True)
    plt.savefig("logs/learning_curve_reward.png", dpi=200)

    # Plot average searches
    plt.figure()
    plt.plot(episodes, avg_searches, marker="o")
    plt.xlabel("Episode")
    plt.ylabel("Average Number of Searches")
    plt.title("Policy Efficiency: Searches per Episode")
    plt.grid(True)
    plt.savefig("logs/learning_curve_searches.png", dpi=200)

    print("Saved learning curves to logs/learning_curve_reward.png and logs/learning_curve_searches.png")
