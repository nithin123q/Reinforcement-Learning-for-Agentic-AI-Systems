
"""Environment/reward utilities for the simulated research tasks."""

def compute_source_reward(task, chosen_source: str) -> float:
    """Reward for picking a particular source for a given task.

    Best source  ->  1.0
    Good sources ->  0.5
    Bad sources  -> -0.2
    Unknown      ->  0.0
    """
    if chosen_source == task["best_source"]:
        return 1.0
    elif chosen_source in task.get("good_sources", []):
        return 0.5
    elif chosen_source in task.get("bad_sources", []):
        return -0.2
    else:
        return 0.0


def quality_level(avg_reward: float) -> str:
    """Discretize average reward into coarse quality levels for the state.

    > 0.7  -> 'high'
    > 0.3  -> 'medium'
    else   -> 'low'
    """
    if avg_reward > 0.7:
        return "high"
    elif avg_reward > 0.3:
        return "medium"
    else:
        return "low"
