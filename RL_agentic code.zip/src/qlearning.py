
"""Tabular Q-learning agent for discrete state/action spaces."""

import random
from collections import defaultdict

class QLearningAgent:
    """Q-learning agent used for high-level workflow decisions.

    Actions correspond to agentic workflow choices:
        - 'search_more'
        - 'summarize'
        - 'stop'
    """
    def __init__(self, actions, alpha=0.1, gamma=0.9, epsilon=0.1):
        self.actions = actions
        self.alpha = alpha      # learning rate
        self.gamma = gamma      # discount factor
        self.epsilon = epsilon  # exploration rate
        self.q = defaultdict(float)  # q[(state, action)] -> value

    def select_action(self, state):
        """Select an action using epsilon-greedy over Q-values."""
        if random.random() < self.epsilon:
            return random.choice(self.actions)

        qs = [self.q[(state, a)] for a in self.actions]
        max_q = max(qs)
        best_actions = [a for a in self.actions if self.q[(state, a)] == max_q]
        return random.choice(best_actions)

    def update(self, state, action, reward, next_state):
        """Standard one-step Q-learning update."""
        max_next_q = max(self.q[(next_state, a)] for a in self.actions)
        old_q = self.q[(state, action)]
        self.q[(state, action)] = old_q + self.alpha * (
            reward + self.gamma * max_next_q - old_q
        )
