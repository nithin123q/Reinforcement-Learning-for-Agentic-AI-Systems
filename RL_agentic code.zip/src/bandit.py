
"""Bandit algorithms for source selection.

We implement a UCB1 bandit to satisfy the 'Exploration Strategies' requirement:
the agent balances exploring less-visited sources and exploiting high-reward ones.
"""
import math
import random
from collections import defaultdict

class UCBBandit:
    """UCB1 bandit for exploration over a fixed set of actions (sources).

    Each action a has:
        - estimated value Q(a)
        - count N(a)

    At each step t, we choose:
        a_t = argmax_a [ Q(a) + c * sqrt( ln(t) / N(a) ) ]
    """
    def __init__(self, actions, c: float = 2.0):
        self.actions = actions
        self.c = c
        self.q_values = defaultdict(float)
        self.action_counts = defaultdict(int)
        self.total_steps = 0

    def select_action(self):
        """Select an action using the UCB1 criterion."""
        self.total_steps += 1

        # Try each action at least once
        for a in self.actions:
            if self.action_counts[a] == 0:
                return a

        ucb_scores = {}
        for a in self.actions:
            n_a = self.action_counts[a]
            exploit = self.q_values[a]
            explore = self.c * math.sqrt(math.log(self.total_steps) / n_a)
            ucb_scores[a] = exploit + explore

        max_score = max(ucb_scores.values())
        best_actions = [a for a, s in ucb_scores.items() if s == max_score]
        return random.choice(best_actions)

    def update(self, action, reward: float):
        """Incremental mean update of Q(action) given observed reward."""
        self.action_counts[action] += 1
        n = self.action_counts[action]
        old_q = self.q_values[action]
        self.q_values[action] = old_q + (reward - old_q) / n
