
"""Main RL training script for the research agentic system.

- Uses a UCBBandit to learn which sources (tools) are most useful.
- Uses Q-learning to learn when to search more vs. summarize vs. stop.
- Logs per-episode metrics to logs/rl_metrics.csv:
    * episode
    * avg_reward      (across tasks)
    * avg_searches    (average number of 'search_more' actions)
"""
import json
import csv
import os

from agents import SearchAgent, SummarizerAgent, RLController
from bandit import UCBBandit
from qlearning import QLearningAgent
from environment import compute_source_reward

def load_tasks():
    with open("data/tasks.json") as f:
        return json.load(f)

if __name__ == "__main__":
    tasks = load_tasks()

    search = SearchAgent()
    summarizer = SummarizerAgent()
    bandit = UCBBandit(
        actions=["blog", "wikipedia", "scholar", "news"],
        c=2.0
    )
    q_agent = QLearningAgent(
        actions=["search_more", "summarize", "stop"],
        alpha=0.1,
        gamma=0.9,
        epsilon=0.1
    )
    controller = RLController(search, summarizer, bandit, q_agent)

    num_episodes = 50
    metrics_path = "logs/rl_metrics.csv"
    os.makedirs("logs", exist_ok=True)

    with open(metrics_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["episode", "avg_reward", "avg_searches"])

        for episode in range(1, num_episodes + 1):
            total_reward = 0.0
            total_searches = 0

            for task in tasks:
                ep_reward, ep_searches = controller.run_episode(task, compute_source_reward)
                total_reward += ep_reward
                total_searches += ep_searches

            avg_reward = total_reward / len(tasks)
            avg_searches = total_searches / len(tasks)
            writer.writerow([episode, avg_reward, avg_searches])
            print(f"Episode {episode}: avg reward = {avg_reward:.3f}, avg searches = {avg_searches:.3f}")

    print("\nTraining complete. Metrics saved to logs/rl_metrics.csv")
