
"""Baseline script: runs a fixed, non-RL pipeline for comparison."""
import json
from agents import SearchAgent, SummarizerAgent, ControllerAgent

def load_tasks():
    with open("data/tasks.json") as f:
        return json.load(f)

if __name__ == "__main__":
    tasks = load_tasks()
    search = SearchAgent()
    summarizer = SummarizerAgent()
    controller = ControllerAgent(search, summarizer)

    for task in tasks:
        print(f"\n=== Task {task['id']}: {task['query']} ===")
        summary = controller.run_fixed_pipeline(task)
        print(summary)
